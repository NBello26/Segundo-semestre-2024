/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package institutoduoc;

/**
 *
 * @author W608-PCXX
 */
public class InstitutoDuoc {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Docente docente1 = new Docente("Calfún", "15.465.456-7","20/03/2018","Puerto Montt", 1);
        Docente docente2 = new Docente("German", "13.234.234-2","22/04/2019","Puerto Montt", 2);
        Alumno alumno1 = new Alumno("Nicolás", "20.982.464-7", "26/02/2002", 22);
        Alumno alumno2 = new Alumno("Rodrigo", "20.065.934-1", "20/03/1999", 25);
        
        Asignatura asignatura1 = new Asignatura("FYD-006D", "Ingles Elemental 1", 6.0,5.7,7.0,docente2,alumno2);
        Asignatura asignatura2 = new Asignatura("DOO-008D", "Desarrollo Orientado a Objetos", 7.0,7.0,7.0,docente1,alumno1);
        
        asignatura1.mostrarAsignatura();
        System.out.println("");
        asignatura2.mostrarAsignatura();
    }
    
}
