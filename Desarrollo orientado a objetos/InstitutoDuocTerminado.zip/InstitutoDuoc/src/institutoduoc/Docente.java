/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package institutoduoc;

/**
 *
 * @author W608-PCXX
 */
public class Docente {
    private String nombreDocente, rut, fecha_ingreso, sede;
    private int numeroDocente;
    
    //Constructor

    public Docente(String nombreDocente, String rut, String fecha_ingreso, String sede, int numeroDocente) {
        this.nombreDocente = nombreDocente;
        this.rut = rut;
        this.fecha_ingreso = fecha_ingreso;
        this.sede = sede;
        this.numeroDocente = numeroDocente;
    }

    public Docente() {
    }
    
    
    //Set

    public void setNombreDocente(String nombreDocente) {
        this.nombreDocente = nombreDocente;
    }

    public void setRut(String rut) {
        this.rut = rut;
    }

    public void setFecha_ingreso(String fecha_ingreso) {
        this.fecha_ingreso = fecha_ingreso;
    }

    public void setSede(String sede) {
        this.sede = sede;
    }

    public void setNumeroDocente(int numeroDocente) {
        this.numeroDocente = numeroDocente;
    }
    
    
    //Get

    public String getNombreDocente() {
        return nombreDocente;
    }

    public String getRut() {
        return rut;
    }

    public String getFecha_ingreso() {
        return fecha_ingreso;
    }

    public String getSede() {
        return sede;
    }

    public int getNumeroDocente() {
        return numeroDocente;
    }
    
    
    //Customer
    
    
    
    //ToString

    @Override
    public String toString() {
        return "Docente{" + "nombreDocente=" + nombreDocente + ", rut=" + rut + ", fecha_ingreso=" + fecha_ingreso + ", sede=" + sede + ", numeroDocente=" + numeroDocente + '}';
    }
    
}
