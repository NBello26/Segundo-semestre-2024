/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package institutoduoc;

/**
 *
 * @author W608-PCXX
 */
public class Alumno {
    private String nombre,rut,fecha_de_nacimiento;
    private int edad;
    
    //Construcctores

    public Alumno(String nombre, String rut, String fecha_de_nacimiento, int edad) {
        this.nombre = nombre;
        this.rut = rut;
        this.fecha_de_nacimiento = fecha_de_nacimiento;
        this.edad = edad;
    }

    public Alumno() {
    }
    
    
    //Set

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setRut(String rut) {
        this.rut = rut;
    }

    public void setFecha_de_nacimiento(String fecha_de_nacimiento) {
        this.fecha_de_nacimiento = fecha_de_nacimiento;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }
    
    
    //Get

    public String getNombre() {
        return nombre;
    }

    public String getRut() {
        return rut;
    }

    public String getFecha_de_nacimiento() {
        return fecha_de_nacimiento;
    }

    public int getEdad() {
        return edad;
    }
    
    
    //Customers
    
    
    //toString

    @Override
    public String toString() {
        return "Alumno{" + "nombre=" + nombre + ", rut=" + rut + ", fecha_de_nacimiento=" + fecha_de_nacimiento + ", edad=" + edad + '}';
    }
    
}
