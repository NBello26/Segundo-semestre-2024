/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package institutoduoc;

/**
 *
 * @author W608-PCXX
 */
public class Asignatura {
    private String codigo, nombre_asignatura;
    private double nota1,nota2,nota3;
    private Docente nombreProfesor;
    private Alumno nombreAlumno;

    public Asignatura(String codigo, String nombre_asignatura, double nota1, double nota2, double nota3, Docente nombreProfesor, Alumno nombreAlumno) {
        this.codigo = codigo;
        this.nombre_asignatura = nombre_asignatura;
        this.nota1 = nota1;
        this.nota2 = nota2;
        this.nota3 = nota3;
        this.nombreProfesor = nombreProfesor;
        this.nombreAlumno = nombreAlumno;
    }

    public Asignatura() {
    }
    
     //Set

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public void setNombre_asignatura(String nombre_asignatura) {
        this.nombre_asignatura = nombre_asignatura;
    }

    public void setNota1(double nota1) {
        this.nota1 = nota1;
    }

    public void setNota2(double nota2) {
        this.nota2 = nota2;
    }

    public void setNota3(double nota3) {
        this.nota3 = nota3;
    }

    public void setNombreProfesor(Docente nombreProfesor) {
        this.nombreProfesor = nombreProfesor;
    }

    public void setNombreAlumno(Alumno nombreAlumno) {
        this.nombreAlumno = nombreAlumno;
    }
    
    //Get

    public String getCodigo() {
        return codigo;
    }

    public String getNombre_asignatura() {
        return nombre_asignatura;
    }

    public double getNota1() {
        return nota1;
    }

    public double getNota2() {
        return nota2;
    }

    public double getNota3() {
        return nota3;
    }

    public Docente getNombreProfesor() {
        return nombreProfesor;
    }

    public Alumno getNombreAlumno() {
        return nombreAlumno;
    }
    
    
    //Customer
    public void mostrarAsignatura(){
        System.out.println("Codigo: " + this.codigo);
        System.out.println("Nombre Asignatura: " + this.nombre_asignatura);
        System.out.println("Nombre Docente: " + this.nombreProfesor.getNombreDocente());
        System.out.println("Nombre Estudiante: " + this.nombreAlumno.getNombre());
        System.out.println("Nota 1: " + this.nota1);
        System.out.println("Nota 2: " + this.nota2);
        System.out.println("Nota 3: " + this.nota3);
    }
    
    
    //ToString

    @Override
    public String toString() {
        return "Asignatura{" + "codigo=" + codigo + ", nombre_asignatura=" + nombre_asignatura + ", nota1=" + nota1 + ", nota2=" + nota2 + ", nota3=" + nota3 + ", nombreProfesor=" + nombreProfesor + ", nombreAlumno=" + nombreAlumno + '}';
    }
    
}


