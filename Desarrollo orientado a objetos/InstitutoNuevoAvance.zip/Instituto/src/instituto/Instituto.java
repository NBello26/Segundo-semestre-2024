/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package instituto;

/**
 *
 * @author W608-PCXX
 */
public class Instituto {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        /*
        Mostrar si la persona pertenece a la jornada diurna o vespertina, en el caso de recibir una d o v
        */
        Estudiante estudiante = new Estudiante("Informatica", "1111111", "Nicolás", 22);
        Docente docente = new Docente("Programación","000000", "Juan", 26);
        docente.mostrarDatos();
        System.out.println("Sueldo: " + docente.sueldo());
    }
    
}
