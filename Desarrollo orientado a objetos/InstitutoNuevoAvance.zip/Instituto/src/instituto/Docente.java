/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package instituto;

/**
 *
 * @author W608-PCXX
 */
public class Docente extends Persona{
    private String asignatura;

    public Docente(String asignatura, String rut, String nombre, int edad) {
        super(rut, nombre, edad);
        this.asignatura = asignatura;
    }

    public Docente(String asignatura) {
        this.asignatura = asignatura;
    }

    public Docente() {
    }

    public String getAsignatura() {
        return asignatura;
    }

    public void setAsignatura(String asignatura) {
        this.asignatura = asignatura;
    }
    
    @Override
    public void mostrarDatos(){
        System.out.println("");
        System.out.println("Mostrando datos del docente");
        super.mostrarDatos();
        System.out.println("Asignatura: " + this.asignatura);
    }
    
    public String categorizacion(){
        if (super.getEdad() >= 40 && super.getEdad() < 80){
            return "Senior";
        }else if(super.getEdad() < 30 && super.getEdad() > 25){
            return "Junior";
        }else if (30 <= super.getEdad() && super.getEdad() < 40){
            return "Regular";
        }else{
            return "Error, edad no existente para ser un docente";
        }
    }
    
    public int sueldo(){
        int sueldo;
        if (categorizacion() == "Senior"){
            sueldo = 1300000;
        }else if (categorizacion() == "Junior"){
            sueldo = 700000;
        }else if (categorizacion() == "Regular"){
            sueldo = 900000;
        }else{
            sueldo = 0;
        }
        return sueldo;
    }

    @Override
    public String toString() {
        return "Docente{" + "asignatura=" + asignatura + '}';
    }
    
    
    
}
