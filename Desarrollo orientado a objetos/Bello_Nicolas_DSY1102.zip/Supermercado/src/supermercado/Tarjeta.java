/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package supermercado;

/**
 *
 * @author W608-PCXX
 */
public class Tarjeta {
    private String idTarjeta, nombreAsociado; //Para el id considere que será del tipo XXXX-XXXX-XXXX por eso es String
    private int cupoTarjeta,saldo;
    
    //Constructores
    //Completo
    public Tarjeta(String idTarjeta, String nombreAsociado, int cupoTarjeta, int saldo) {
        this.idTarjeta = idTarjeta;
        this.nombreAsociado = nombreAsociado;
        this.cupoTarjeta = cupoTarjeta;
        this.saldo = saldo;
    }
    //Vacío
    public Tarjeta() {
    }
    
    
    //Set()
    public void setIdTarjeta(String idTarjeta) {
        this.idTarjeta = idTarjeta;
    }

    public void setNombreAsociado(String nombreAsociado) {
        this.nombreAsociado = nombreAsociado;
    }

    public void setCupoTarjeta(int cupoTarjeta) {
        this.cupoTarjeta = cupoTarjeta;
    }
    
    public void setSaldo(int saldo) {
        this.saldo = saldo;
    }
    //Get()
    public String getIdTarjeta() {
        return idTarjeta;
    }

    public String getNombreAsociado() {
        return nombreAsociado;
    }

    public int getCupoTarjeta() {
        return cupoTarjeta;
    }
    
    public int getSaldo() {
        return saldo;
    }
    
    //Customer
    //Retorna que tipo de cliente es (Premium, Gold o Básico)
    public String tipoCliente(){
        String tipoDeCliente = "";
        if ((this.cupoTarjeta >= 0) && (this.cupoTarjeta < 250000)){
            tipoDeCliente = "Cliente Básico";
        }else if ((this.cupoTarjeta < 500000) && (this.cupoTarjeta >= 250000)){
            tipoDeCliente = "Cliente Premium";
        }else if (this.cupoTarjeta >= 500000){
            tipoDeCliente = "Cliente Gold";
        }else{
            tipoDeCliente = "Tipo de cliente invalido, el cupo es negativo";
        }
        return tipoDeCliente;
    }
    //Muestra el saldo restante tras una compra o dice saldo insuficiente en caso de que la compra supere el cupo
    public void saldoRestante(int totalCompra){
        System.out.println("");
        if (totalCompra > this.saldo){
            System.out.println("Saldo de la tarjeta insuficiente, " + this.nombreAsociado + " el total de su compra excede el saldo de la tarjeta");
        }else if (totalCompra >= 0){
            int totalfinal = this.saldo - totalCompra;
            System.out.println("** Boleta electronica **");
            System.out.println("ID Tarjeta: " + this.idTarjeta);
            System.out.println("Cliente: " + this.nombreAsociado);
            System.out.println("Tipo de cliente: " + tipoCliente());
            System.out.println("Cupo de la tarjeta: " + this.cupoTarjeta);
            System.out.println("Saldo en la tarjeta: " + this.saldo);
            System.out.println("Total de la compra: " + totalCompra);
            System.out.println("");
            System.out.println("Saldo restante: " + (totalfinal));
            System.out.println("** Boleta electronica **");
            setSaldo(totalfinal);
        }else{
            System.out.println("Ingrese un número de total de compra positivo");
        }
    }
    //Muestra el descuento que tendra la persona dependiendo del dia entregado
    public void descuentoDia(String dia){
        if (("LUNES".equals(dia)) && (!"Tipo de cliente invalido, el cupo es negativo".equals(tipoCliente()))){
            if ("Cliente Básico".equals(tipoCliente())){
                System.out.println("Cliente " + this.nombreAsociado + " usted tiene un descuento de 10% al ser Cliente Básico y ser día Lunes");
            }else{
                System.out.println("Cliente " + this.nombreAsociado + " usted no tiene un descuento el día Lunes");
            }
        }else if (("MIERCOLES".equals(dia)) && (!"Tipo de cliente invalido, el cupo es negativo".equals(tipoCliente()))){
            if ("Cliente Premium".equals(tipoCliente())){
                System.out.println("Cliente " + this.nombreAsociado + " usted tiene un descuento de 15% al ser Cliente Premium y ser día Miercoles");
            }else{
                System.out.println("Cliente " + this.nombreAsociado + " usted no tiene un descuento el día Miercoles");
            }
        }else if (("VIERNES".equals(dia)) && (!"Tipo de cliente invalido, el cupo es negativo".equals(tipoCliente()) )){
            if ("Cliente Gold".equals(tipoCliente())){
                System.out.println("Cliente " + this.nombreAsociado + " usted tiene un descuento de 20% al ser Cliente Gold y ser día Viernes");
            }else{
                System.out.println("Cliente " + this.nombreAsociado + " usted no tiene un descuento el día Viernes");
            }
        }else if (("MARTES".equals(dia)) || ("JUEVES".equals(dia)) || ("SABADO".equals(dia)) || ("DOMINGO".equals(dia))){
            System.out.println("Cliente " + this.nombreAsociado + " usted no tiene un descuento el día de hoy");
        }else{
            System.out.println("Día ingresado no valido");
        }
    }
    //To string
    @Override
    public String toString() {
        return "Tarjeta{" + "idTarjeta=" + idTarjeta + ", nombreAsociado=" + nombreAsociado + ", cupoTarjeta=" + cupoTarjeta + ", saldo=" + saldo + '}';
    }
    
    
}
