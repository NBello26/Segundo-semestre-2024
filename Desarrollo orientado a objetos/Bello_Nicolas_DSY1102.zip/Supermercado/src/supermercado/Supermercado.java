/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package supermercado;
import  java.util.Scanner;
/**
 *
 * @author W608-PCXX
 */
public class Supermercado {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String opcion,opcionTarjeta,opcionDia;
        int opcionCompra;
        Tarjeta tarjeta1 = new Tarjeta("4000-4000-4000", "Nicolás", 100000, 100000);
        Tarjeta tarjeta2 = new Tarjeta("5555-5555-5555", "Calfún", 1000000, 1000000);
        do{
            System.out.println("");
            System.out.println("*** Bienvenido a supermercadoDuoc ***");
            System.out.println("1.- Cliente 1: " + tarjeta1.getNombreAsociado());
            System.out.println("2.- Cliente 2: " + tarjeta2.getNombreAsociado());
            System.out.println("3.- Salir del programa");
            System.out.println("Entrege el número del cliente que es usted(1 o 2): ");
            opcion = teclado.next();
            if("1".equals(opcion)){
                do{
                    System.out.println("");
                    System.out.println("** Bienvenido " + tarjeta1.getNombreAsociado() + " al supermercadoDuoc **");
                    System.out.println("1.- Mostrar tipo de cliente");
                    System.out.println("2.- Cupo restante tras la compra");
                    System.out.println("3.- Descuento aplicable");
                    System.out.println("4.- Salir del menú Cliente");
                    opcionTarjeta = teclado.next();
                    if ("1".equals(opcionTarjeta)){
                        System.out.println("");
                        System.out.println("Cliente: " + tarjeta1.getNombreAsociado());
                        System.out.println(tarjeta1.tipoCliente());
                        System.out.println("Saldo: " + tarjeta1.getSaldo());
                    }else if ("2".equals(opcionTarjeta)){
                        System.out.println("");
                        System.out.println("Ingrese el total de su compra(Solo números enteros positivos): ");
                        opcionCompra = teclado.nextInt();
                        tarjeta1.saldoRestante(opcionCompra);
                    }else if ("3".equals(opcionTarjeta)){
                        System.out.println("");
                        System.out.println("Ingrese el dia actual(Todo en mayusculas): ");
                        opcionDia = teclado.next();
                        tarjeta1.descuentoDia(opcionDia);
                    }else if ("4".equals(opcionTarjeta)){
                        System.out.println("....Volviendo al menú principal");
                    }else{
                        System.out.println("Opción ingresada no valida, intentelo nuevamente");
                    }
                }while (!"4".equals(opcionTarjeta));
            }else if ("2".equals(opcion)){
                do{
                    System.out.println("");
                    System.out.println("** Bienvenido " + tarjeta2.getNombreAsociado() + " al supermercadoDuoc **");
                    System.out.println("1.- Mostrar tipo de cliente");
                    System.out.println("2.- Cupo restante tras la compra");
                    System.out.println("3.- Descuento aplicable");
                    System.out.println("4.- Salir del menú Cliente");
                    opcionTarjeta = teclado.next();
                    if ("1".equals(opcionTarjeta)){
                        System.out.println("");
                        System.out.println("Cliente: " + tarjeta2.getNombreAsociado());
                        System.out.println(tarjeta2.tipoCliente());
                        System.out.println("Saldo: " + tarjeta2.getSaldo());
                    }else if ("2".equals(opcionTarjeta)){
                        System.out.println("");
                        System.out.println("Ingrese el total de su compra(Solo números enteros positivos): ");
                        opcionCompra = teclado.nextInt();
                        tarjeta2.saldoRestante(opcionCompra);
                    }else if ("3".equals(opcionTarjeta)){
                        System.out.println("");
                        System.out.println("Ingrese el dia actual(Todo en mayusculas): ");
                        opcionDia = teclado.next();
                        tarjeta2.descuentoDia(opcionDia);
                    }else if ("4".equals(opcionTarjeta)){
                        System.out.println("....Volviendo al menú principal");
                    }else{
                        System.out.println("Opción ingresada no valida, intentelo nuevamente");
                    }
                }while (!"4".equals(opcionTarjeta));
            }else if ("3".equals(opcion)){
                System.out.println("");
                System.out.println("....Saliendo del programa");
            }else{
                System.out.println("");
                System.out.println("Ingrese una opción valida, intentelo nuevamnete");
            }
        }while (!"3".equals(opcion));
    }
    
}
