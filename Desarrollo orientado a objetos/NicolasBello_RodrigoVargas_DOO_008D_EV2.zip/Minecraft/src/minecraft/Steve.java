/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package minecraft;

public class Steve extends PersonajeMinecraft{
    private String armadura;
    private String herramienta;

    public Steve(String nombre, int salud, int nivel, String armadura, String herramienta) {
        super(nombre, salud, nivel);
        this.armadura = armadura;
        this.herramienta = herramienta;
    }

    public Steve() {
    }

    public void setArmadura(String armadura) {
        this.armadura = armadura;
    }

    public void setHerramienta(String herramienta) {
        this.herramienta = herramienta;
    }
    
    

    @Override
    public void accion(){
        System.out.println("Steve va a recolectar minerales.");
        if ((super.getNivel())>5){
            System.out.println("Steve supera el nivel 5, por lo tanto va a recolectar el doble de recursos.");
            System.out.println("Steve recolecta 6 de Lapizlázuli.");

        }else if((super.getNivel())>=0 && ((super.getNivel())<=5)){
            System.out.println("Steve recolecta 3 de Lapizlázuli utilizando una picota.");

        }else{
            System.out.println("El personaje no existe");
        }
    }
    
    @Override
    public void mostrarInfo(){
        System.out.println("Nombre: "+ super.getNombre());
        System.out.println("Salud: " + super.getSalud());
        System.out.println("Nivel: " + super.getNivel());
        System.out.println("Armadura: " + armadura);
        System.out.println("Herramienta: " + herramienta);
    }
    
    
    
}
