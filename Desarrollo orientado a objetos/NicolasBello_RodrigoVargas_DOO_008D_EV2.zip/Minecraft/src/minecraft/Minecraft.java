package minecraft;

import java.util.Scanner;

public class Minecraft {

    /**
     * @param args the command line arguments
     */
    @SuppressWarnings("empty-statement")
    public static void main(String[] args) {
        // TODO code application logic here
        Steve steve = new Steve();
        Alex alex = new Alex();
        int ataqueMob;
        EnemigoMinecraft mob = new EnemigoMinecraft();
        Scanner teclado = new Scanner(System.in);
        String opcion;
        String opcionataque;
        String opcionpersonajes;
        //Opciones de crear personajes por defecto o ingresados por el usuario.
        System.out.println("¡Bienvenido a la creación de personajes!");
        System.out.println("");
        System.out.println("Creando personajes....");
        System.out.println("1.- Crear por defecto");
        System.out.println("Entregue cualquier tecla para crear los personajes por tu cuenta");
        System.out.print("Seleccione una opción (1 o cualquiera): ");
        opcionpersonajes = teclado.nextLine();
        int i = 0;
        //Validación de la opción ingresada para creación de personajes por defecto
        if ("1".equals(opcionpersonajes)) {
            System.out.println("Creando por defecto");
            steve.setNombre("Steve");
            steve.setNivel(0);
            steve.setSalud(100);
            steve.setArmadura("cuero");
            steve.setHerramienta("picota de diamante");
            alex.setNombre("Alex");
            alex.setNivel(0);
            alex.setSalud(90);
            alex.setAlmacenamiento("Shulker");
            alex.setMaterialConstruccion("Madera");
            mob.setNombre("Creeper");
            mob.setFuerzaAtaque(55);
        } else {
            //Creación de personajes por parte del usuario de acuerdo al input registrado previamente
            while (i < 2) {
                if (i == 0) {
                    System.out.println("Creando a Steve...");
                } else if (i == 1) {
                    System.out.println("");
                    System.out.println("Creando a Alex...");
                }
                System.out.println("Introduzca cuanta salud tendra(número mayor a 0): ");
                int salud = teclado.nextInt();
                teclado.nextLine();
                System.out.println("Su personaje comenzara con nivel 0");
                int nivel = 0;
                if (i == 0) {
                    System.out.println("Ingrese el tipo de armadura que tiene Steve: ");
                    String armadura = teclado.nextLine();
                    System.out.println("Ingrese el tipo de herramienta que tiene Steve: ");
                    String herramienta = teclado.nextLine();
                    steve.setNombre("Steve");
                    steve.setNivel(nivel);
                    steve.setSalud(salud);
                    steve.setArmadura(armadura);
                    steve.setHerramienta(herramienta);

                } else if (i == 1) {
                    System.out.println("Ingrese el tipo de almacenamiento que tiene Alex: ");
                    String almacenamiento = teclado.nextLine();
                    System.out.println("Ingrese el tipo de material de construcción que tiene Alex: ");
                    String material = teclado.nextLine();
                    alex.setNombre("Alex");
                    alex.setNivel(nivel);
                    alex.setSalud(salud);
                    alex.setAlmacenamiento(almacenamiento);
                    alex.setMaterialConstruccion(material);

                }
                i++;
            }
            System.out.println("");
            System.out.println("Creando al enemigo...");
            System.out.println("Introduzca un nombre:");
            String nombre = teclado.nextLine();
            System.out.println("Introduzca el poder de ataque que tendrá(número mayor a 0): ");
            int ataque = teclado.nextInt();
            teclado.nextLine();
            mob.setNombre(nombre);
            mob.setFuerzaAtaque(ataque);
        }
        System.out.println("");
        System.out.println("Mostrando datos de Steve...");
        steve.mostrarInfo();
        System.out.println("");
        System.out.println("Mostrando datos de Alex...");
        alex.mostrarInfo();
        System.out.println("");
        System.out.println("Mostrando datos del Mob...");
        mob.mostrarInfo();
        do {
            //Menú de opciones principal
            System.out.println("");
            System.out.println("Menú de Opciones:");
            System.out.println("1. Acción de Steve");
            System.out.println("2. Acción de Alex");
            System.out.println("3. Ataque de mob");
            System.out.println("4. Mostrar información Steve");
            System.out.println("5. Mostrar información Alex");
            System.out.println("6. Mostrar información Mob");
            System.out.println("7. Salir del programa");

            System.out.print("Seleccione una opción (1-7): ");
            opcion = teclado.nextLine();  // Leer la opción ingresada por el usuario

            switch (opcion) {
                case "1":
                    System.out.println("");
                    if (steve.getNivel() >= 0) {
                        System.out.println("Nivel inicial: " + steve.getNivel());
                        steve.accion();
                        System.out.println("Steve terminó de recolectar recursos");
                        steve.ganarExperiencia();
                    } else {
                        System.out.println("El personaje no existe.");
                    }
                    break;
                case "2":
                    System.out.println("");
                    if (alex.getNivel() >= 0) {
                        System.out.println("Nivel inicial: " + alex.getNivel());
                        alex.accion();
                        System.out.println("Terminó de construir");
                        alex.ganarExperiencia();
                    } else {
                        System.out.println("El personaje no existe.");
                    }
                    break;
                case "3":
                    do {
                        //Menú de opciones para el ataque del mob
                        System.out.println("");
                        System.out.println("El mob esta atacando");
                        System.out.println("Elige la opcion a atacar:");
                        System.out.println("1.- Steve");
                        System.out.println("2.- Alex");
                        System.out.println("3.- Volver al menú principal");
                        System.out.print("Seleccione una opción (1-3): ");
                        opcionataque = teclado.nextLine();

                        switch (opcionataque) {
                            case "1":
                                System.out.println("");
                                if (steve.getNivel() >= 0) {
                                    System.out.println("El mob atacará a Steve");
                                    ataqueMob = mob.atacar();
                                    steve.perderSalud(ataqueMob);
                                    System.out.println("Salud restante de Steve: " + steve.getSalud());
                                } else {
                                    System.out.println("El personaje no existe.");
                                }
                                break;
                            case "2":
                                System.out.println("");
                                if (alex.getNivel() >= 0) {
                                    System.out.println("El mob atacará a Alex");
                                    ataqueMob = mob.atacar();
                                    alex.perderSalud(ataqueMob);
                                    System.out.println("Salud restante de Alex: " + alex.getSalud());
                                } else {
                                    System.out.println("El personaje no existe.");
                                }
                                break;
                            case "3":
                                System.out.println("Volviendo al menú principal");
                                break;
                            default:
                                System.out.println("Opción no válida, por favor intente de nuevo.");
                        }
                    } while (!"3".equals(opcionataque));

                    break;
                case "4":
                    System.out.println("");
                    if (steve.getNivel() >= 0) {
                        System.out.println("*** Mostrando información de Steve ***");
                        steve.mostrarInfo();
                        System.out.println("*** Mostrando información de Steve ***");
                    } else {
                        System.out.println("El personaje no existe.");
                    }
                    break;
                case "5":
                    System.out.println("");
                    if (alex.getNivel() >= 0) {
                        System.out.println("*** Mostrando información de Alex ***");
                        alex.mostrarInfo();
                        System.out.println("*** Mostrando información de Alex ***");
                    } else {
                        System.out.println("El personaje no existe.");
                    }
                    break;
                case "6":
                    System.out.println("");
                    System.out.println("*** Mostrando información del Mob ***");
                    mob.mostrarInfo();
                    System.out.println("*** Mostrando información del Mob ***");
                    break;
                case "7":
                    System.out.println("Saliendo del programa...");
                    break;
                default:
                    System.out.println("Opción no válida, por favor intente de nuevo.");
            }
            System.out.println();  // Espacio en blanco para mejor lectura
        } while (!"7".equals(opcion));  // El menú se repite hasta que el usuario elija la opción 7 (salir)
    }
}
