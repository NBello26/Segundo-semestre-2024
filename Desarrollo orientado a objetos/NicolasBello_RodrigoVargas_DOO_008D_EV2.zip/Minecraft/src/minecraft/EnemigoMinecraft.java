/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package minecraft;

/**
 *
 * @author Y409-PCXX
 */
public class EnemigoMinecraft implements Atacable{
    private String nombre;
    private int fuerzaAtaque;
    
    //Constructores
    public EnemigoMinecraft(String nombre, int fuerzaAtaque) {
        this.nombre = nombre;
        this.fuerzaAtaque = fuerzaAtaque;
    }

    public EnemigoMinecraft() {
    }
    
    //Get
    public String getNombre() {
        return nombre;
    }

    public int getFuerzaAtaque() {
        return fuerzaAtaque;
    }
    
    //Set
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setFuerzaAtaque(int fuerzaAtaque) {
        this.fuerzaAtaque = fuerzaAtaque;
    }
    
    //MostrarInfo
    public void mostrarInfo(){
        System.out.println("** Datos del mob **");
        System.out.println("Nombre: "+ nombre);
        System.out.println("Fuerza de ataque: " + fuerzaAtaque);
        System.out.println("** Datos del mob **");
    }
    
    @Override
    public int atacar(){
        if(fuerzaAtaque > 50){
            int fuerza = fuerzaAtaque * 2;
            System.out.println("El mob " + nombre + " tiene mas de 50 de fuerza por lo que se duplicará a la hora de atacar");
            System.out.println("El mob " + nombre + " a realizado " + fuerza + "(" + fuerzaAtaque + " * 2) de daño al jugador");
            return fuerza;
        }else if((fuerzaAtaque > 0) && (fuerzaAtaque <= 50)){
            System.out.println("El mob " + nombre + " a realizado " + fuerzaAtaque + " de daño al jugador ");
            return fuerzaAtaque;
        }else{
            System.out.println("El mob " + nombre + " no tiene fuerza por lo que no realiza daño al jugador");
            return 0;
        }
    }
}
