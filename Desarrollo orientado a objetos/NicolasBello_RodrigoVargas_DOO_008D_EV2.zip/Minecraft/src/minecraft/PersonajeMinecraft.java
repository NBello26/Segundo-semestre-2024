/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package minecraft;

abstract public class PersonajeMinecraft {
    private String nombre;
    private int salud;
    private int nivel;
    
    //Constructores

    public PersonajeMinecraft(String nombre, int salud, int nivel) {
        this.nombre = nombre;
        this.salud = salud;
        this.nivel = nivel;
    }

    public PersonajeMinecraft() {
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setSalud(int salud) {
        this.salud = salud;
    }

    public void setNivel(int nivel) {
        this.nivel = nivel;
    }

    public String getNombre() {
        return nombre;
    }

    public int getSalud() {
        return salud;
    }

    public int getNivel() {
        return nivel;
    }
    
    
    abstract public void accion();
    
    final public void perderSalud(int ataque){
        if (salud != 0){
            if(salud > ataque){
            System.out.println("El personaje " + nombre + " ha recibido " + ataque + " puntos de daño");
            setSalud((salud-ataque));
            }else{
                System.out.println("El personaje ha muerto...");
                setNombre("");
                setSalud(-1);
                setNivel(-1);
            }
        }else{
            System.out.println("El personaje no existe por lo que no puede perder salud");
        }
    }
    public void ganarExperiencia(){
        System.out.println("El personaje "+ nombre + " ha realizado una acción. El nivel ha aumentado en 1.");
        setNivel(nivel+1);
        System.out.println("Nivel actual: " + nivel);
    }     
    
    public void mostrarInfo(){
        System.out.println("Mostrando información de: "+ nombre);
        System.out.println("Salud: " + salud);
        System.out.println("Nivel: " + nivel);
    }
}
