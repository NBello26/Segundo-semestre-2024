/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package minecraft;
public class Alex extends PersonajeMinecraft{
    private String almacenamiento;
    private String materialConstruccion;

    public Alex(String nombre, int salud, int nivel,String almacenamiento,String materialConstruccion) {
        super(nombre, salud, nivel);
        this.almacenamiento = almacenamiento;
        this.materialConstruccion = materialConstruccion;
    }

    public Alex() {
    }

    public void setAlmacenamiento(String almacenamiento) {
        this.almacenamiento = almacenamiento;
    }

    public void setMaterialConstruccion(String materialConstruccion) {
        this.materialConstruccion = materialConstruccion;
    }
    
    
    
    @Override
    public void accion(){
        if ((super.getNivel())>3){
            System.out.println("Alex supera el nivel 3, por lo tanto ha desbloqueado granjas automáticas!.");
            System.out.println("Alex ha construido una granja automática.");
 
        }else if((super.getNivel())<=3 && ((super.getNivel())>=0)){
            System.out.println("Alex construye una granja automática de hierro con el apoyo de su shulker.");
            System.out.println("Alex ha construido una casa.");

        }else{
            System.out.println("El personaje no existe");
        }
    }
    
    @Override
    public void mostrarInfo(){
        System.out.println("Nombre: "+ super.getNombre());
        System.out.println("Salud: " + super.getSalud());
        System.out.println("Nivel: " + super.getNivel());
        System.out.println("Almacenamiento basado en: " + almacenamiento);
        System.out.println("Material de construcción: " + materialConstruccion);
    }
    
    
    
    

    
}
