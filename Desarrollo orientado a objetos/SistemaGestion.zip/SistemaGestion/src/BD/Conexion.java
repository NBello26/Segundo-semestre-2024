/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BD;
import java.sql.Connection;
import java.sql.DriverManager;
/**
 *
 * @author W608-PCXX
 */
public class Conexion {
    public Connection obtenerConexion(){
        Connection conexion  = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conexion = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/sistemagestion","root","duoc");
            System.out.println("Conexión exitosa");
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return conexion;
    }
}
