/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;
import BD.Conexion;
import Modelo.Estudiante;
/**
 *
 * @author W608-PCXX
 */
public class InsertarEstudiante {
    public void insertarEstudiante(Estudiante estudiante){
        Conexion con = new Conexion();  
        con.obtenerConexion();
        
        String sql = "INSERT INTO sistemagestion.estudiante VALUES(?,?,?,?,?)";
    }
}
