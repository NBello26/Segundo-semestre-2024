/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sistemagestion;

/**
 *
 * @author W608-PCXX
 */

import java.sql.Connection;
import java.sql.DriverManager;


public class SistemaGestion {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Connection conexion  = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conexion = DriverManager.getConnection("");
            System.out.println("Conexión exitosa");
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }
    
}
