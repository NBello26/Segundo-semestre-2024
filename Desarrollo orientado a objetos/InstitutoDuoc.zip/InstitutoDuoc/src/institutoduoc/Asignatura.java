/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package institutoduoc;

/**
 *
 * @author W608-PCXX
 */
public class Asignatura {
    private String codigo, nombre_asignatura, nombre_alumno, nombre_docente;
    private float nota1,nota2,nota3;
}
