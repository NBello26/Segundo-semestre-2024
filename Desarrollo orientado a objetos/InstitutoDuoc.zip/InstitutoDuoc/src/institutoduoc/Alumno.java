/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package institutoduoc;

/**
 *
 * @author W608-PCXX
 */
public class Alumno {
    private String nombre,rut,fecha_de_nacimiento;
    private int edad;
    
}
