/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package veterinaria;

/**
 *
 * @author W608-PCXX
 */
public class Mascota {
    //Atributos
    private String nombre;
    private int numChip;
    private double peso;
    private int edad;
    
    //Contructor
    public Mascota(String nombre, int numChip, double peso, int edad) {
        this.nombre = nombre;
        this.numChip = numChip;
        this.peso = peso;
        this.edad = edad;
    }
    //Constructor vacío
    public Mascota() {
    }
    
    //Set
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setNumChip(int numChip) {
        this.numChip = numChip;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }
    
    //Get
    public String getNombre() {
        return nombre;
    }

    public int getNumChip() {
        return numChip;
    }

    public double getPeso() {
        return peso;
    }

    public int getEdad() {
        return edad;
    }
    
    //Métodos especiales
    public void mostrarDatos(){
        System.out.println("");
        System.out.println("** Mostrando datos **");
        System.out.println("** Nombre: " + nombre + "   **");
        System.out.println("** Edad: " + edad + "         **");
        System.out.println("** Numero chip: " + numChip + "  **");
        System.out.println("** Peso: " + peso + "       **"); 
        System.out.println("** Mostrando datos **");
    }
    
    //To string
    @Override
    public String toString() {
        return "Mascota{" + "nombre=" + nombre + ", numChip=" + numChip + ", peso=" + peso + ", edad=" + edad + '}';
    }
    
}
