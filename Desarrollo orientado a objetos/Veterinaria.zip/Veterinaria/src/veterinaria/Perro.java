/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package veterinaria;

/**
 *
 * @author W608-PCXX
 */
public class Perro extends Mascota{

    public Perro(String nombre, int numChip, double peso, int edad) {
        super(nombre, numChip, peso, edad);
    }

    public Perro() {
    }
    @Override
    public void mostrarDatos(){
        System.out.println("");
        System.out.println("** Es un perro **");
        super.mostrarDatos();
    }
    
    public void raza(){
        System.out.println("");
        System.out.println("** Identificando raza     **");
        if (super.getPeso() > 12.0){
            System.out.println("** " + super.getNombre() + " es raza grande   **");
        }else if ((super.getPeso() <= 12.0) && (super.getPeso() >= 8.0)){
            System.out.println("** " + super.getNombre() + " es raza regular  **");
        }else if ((super.getPeso() <= 8.0) && (super.getPeso() >= 0.0)){
            System.out.println("** " + super.getNombre() + " es raza pequeña **");
        }else{
            System.out.println("** Peso invalido          **");
        }
        System.out.println("** Identificando raza     **");
    }
}
