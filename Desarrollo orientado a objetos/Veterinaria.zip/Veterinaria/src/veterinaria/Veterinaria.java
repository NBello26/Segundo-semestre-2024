/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package veterinaria;

/**
 *
 * @author W608-PCXX
 */
public class Veterinaria {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Perro perro = new Perro("Kakas", 001,21.3,3);
        Hamster hamster = new Hamster("Hahas", 002,1.3,2);
        
        perro.mostrarDatos();
        hamster.mostrarDatos();
        perro.raza();
    }
    
}
