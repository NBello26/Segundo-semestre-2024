/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package veterinaria;

/**
 *
 * @author W608-PCXX
 */
public class Hamster extends Mascota{

    public Hamster(String nombre, int numChip, double peso, int edad) {
        super(nombre, numChip, peso, edad);
    }

    public Hamster() {
    }
    
    @Override
    public void mostrarDatos(){
        System.out.println("");
        System.out.println("** Es un Hamster **");
        super.mostrarDatos();
    }
}
