/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package instituto;

/**
 *
 * @author W608-PCXX
 */
public class Estudiante extends Persona {
    private String carrera;

    public Estudiante(String carrera, String rut, String nombre, int edad) {
        super(rut, nombre, edad);
        this.carrera = carrera;
    }

    public Estudiante() {
    }

    public void setCarrera(String carrera) {
        this.carrera = carrera;
    }

    public String getCarrera() {
        return carrera;
    }
    
    @Override
    public void mostrarDatos(){
        System.out.println("");
        System.out.println("Mostrando datos del estudiante");
        super.mostrarDatos();
        System.out.println("Carrera: " + this.carrera);
    }
    
    
}
