/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package instituto;

/**
 *
 * @author W608-PCXX
 */
public class Docente extends Persona{
    private String asignatura;

    public Docente(String asignatura, String rut, String nombre, int edad) {
        super(rut, nombre, edad);
        this.asignatura = asignatura;
    }

    public Docente(String asignatura) {
        this.asignatura = asignatura;
    }

    public Docente() {
    }

    public String getAsignatura() {
        return asignatura;
    }

    public void setAsignatura(String asignatura) {
        this.asignatura = asignatura;
    }
    
    @Override
    public void mostrarDatos(){
        System.out.println("");
        System.out.println("Mostrando datos del docente");
        super.mostrarDatos();
        System.out.println("Asignatura: " + this.asignatura);
    }

    @Override
    public String toString() {
        return "Docente{" + "asignatura=" + asignatura + '}';
    }
    
    
    
}
