/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package instituto;
import java.util.Scanner;
/**
 *
 * @author W608-PCXX
 */
public class Docente extends Persona{
    private String asignatura;

    public Docente(String asignatura, String rut, String nombre, int edad) {
        super(rut, nombre, edad);
        this.asignatura = asignatura;
    }

    public Docente(String asignatura) {
        this.asignatura = asignatura;
    }

    public Docente() {
    }

    public String getAsignatura() {
        return asignatura;
    }

    public void setAsignatura(String asignatura) {
        this.asignatura = asignatura;
    }
    
    @Override
    public void mostrarDatos(){
        System.out.println("");
        System.out.println("Mostrando datos del docente");
        System.out.println("Rut: " + super.getRut());
        System.out.println("Nombre: " + super.getNombre());
        System.out.println("Edad: " + super.getEdad());
        System.out.println("Asignatura: " + this.asignatura);
    }
    
    public String categorizacion(){
        if (super.getEdad() >= 40 && super.getEdad() < 80){
            return "Senior";
        }else if(super.getEdad() < 30 && super.getEdad() > 25){
            return "Junior";
        }else if (30 <= super.getEdad() && super.getEdad() < 40){
            return "Regular";
        }else{
            return "Error, edad no existente para ser un docente";
        }
    }
    
    public int sueldo(){
        int sueldo;
        if (categorizacion() == "Senior"){
            sueldo = 1300000;
        }else if (categorizacion() == "Junior"){
            sueldo = 700000;
        }else if (categorizacion() == "Regular"){
            sueldo = 900000;
        }else{
            sueldo = 0;
        }
        return sueldo;
    }

    @Override
    public String toString() {
        return "Docente{" + "asignatura=" + asignatura + '}';
    }

    @Override
    public void actualizarDatos() {
        String opcion, nuevoDato;
        int nuevoDatoInt;
        Scanner scanner = new Scanner(System.in);
        do{
            System.out.println("");
            System.out.println("Menu actualizar Docente");
            System.out.println("1.- Modificar nombre");
            System.out.println("2.- Modificar edad");
            System.out.println("3.- Modificar Asignatura");
            System.out.println("4.- Mostrar datos");
            System.out.println("5.- Salir");
            System.out.println("Ingrese la opción que desea: ");
            opcion = scanner.next();
            if (null == opcion){
                System.out.println("Ingrese una opción correcta. intentelo nuevamente");
            }else switch (opcion) {
                case "1" -> {
                    System.out.println("");
                    System.out.println("Ingrese el nuevo nombre: ");
                    nuevoDato = scanner.next();
                    System.out.println("Nombre cambiado exitosamente, el docente "+ super.getNombre() + " ahora se llamará " + nuevoDato);
                    super.setNombre(nuevoDato);
                }
                case "2" -> {
                    System.out.println("");
                    System.out.println("Ingrese la nueva edad: ");
                    nuevoDatoInt = scanner.nextInt();
                    scanner.nextLine();
                    System.out.println("Edad cambiada exitosamente, el docente "+ super.getEdad() + " ahora tiene " + nuevoDatoInt + " años");
                    super.setEdad(nuevoDatoInt);
                }
                case "3" -> {
                    System.out.println("");
                    System.out.println("Ingrese la nueva carrera: ");
                    nuevoDato = scanner.next();
                    System.out.println("Carrera cambiada exitosamente, el docente "+ super.getNombre() + " ahora estará en la asignatura " + nuevoDato);
                    setAsignatura(nuevoDato);
                }
                case "4" -> {
                    System.out.println("");
                    mostrarDatos();
                }
                case "5" -> System.out.println("Saliendo del programa...");
                default -> System.out.println("Ingrese una opción correcta. intentelo nuevamente");
            }
        }while(!"5".equals(opcion));
    }
    
    
    
}
