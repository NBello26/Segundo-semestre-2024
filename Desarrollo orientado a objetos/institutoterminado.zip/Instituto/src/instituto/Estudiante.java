/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package instituto;
import java.util.Scanner;
/**
 *
 * @author W608-PCXX
 */
public class Estudiante extends Persona {
    private String carrera;

    public Estudiante(String carrera, String rut, String nombre, int edad) {
        super(rut, nombre, edad);
        this.carrera = carrera;
    }

    public Estudiante() {
    }

    public void setCarrera(String carrera) {
        this.carrera = carrera;
    }

    public String getCarrera() {
        return carrera;
    }
    
    @Override
    public void mostrarDatos(){
        System.out.println("");
        System.out.println("Mostrando datos del estudiante");
        System.out.println("Rut: " + super.getRut());
        System.out.println("Nombre: " + super.getNombre());
        System.out.println("Edad: " + super.getEdad());
        System.out.println("Carrera: " + this.carrera);
    }

    @Override
    public void actualizarDatos() {
        boolean flag = true;
        String opcion, nuevoDato;
        int nuevoDatoInt;
        Scanner scanner = new Scanner(System.in);
        do{
            System.out.println("");
            System.out.println("Menu actualizar alumno");
            System.out.println("1.- Modificar nombre");
            System.out.println("2.- Modificar edad");
            System.out.println("3.- Modificar carrera");
            System.out.println("4.- Mostrar datos");
            System.out.println("5.- Salir");
            System.out.println("Ingrese la opción que desea: ");
            opcion = scanner.next();
            if (null == opcion){
                System.out.println("Ingrese una opción correcta. intentelo nuevamente");
            }else switch (opcion) {
                case "1" -> {
                    System.out.println("");
                    System.out.println("Ingrese el nuevo nombre: ");
                    nuevoDato = scanner.next();
                    System.out.println("Nombre cambiado exitosamente, el estudiante "+ super.getNombre() + " ahora se llamará " + nuevoDato);
                    super.setNombre(nuevoDato);
                }
                case "2" -> {
                    System.out.println("");
                    System.out.println("Ingrese la nueva edad: ");
                    nuevoDatoInt = scanner.nextInt();
                    scanner.nextLine();
                    System.out.println("Edad cambiada exitosamente, el estudiante "+ super.getEdad() + " ahora tiene " + nuevoDatoInt + " años");
                    super.setEdad(nuevoDatoInt);
                }
                case "3" -> {
                    System.out.println("");
                    System.out.println("Ingrese la nueva carrera: ");
                    nuevoDato = scanner.next();
                    System.out.println("Carrera cambiada exitosamente, el estudiante "+ super.getNombre() + " ahora estará en la carrera " + nuevoDato);
                    setCarrera(nuevoDato);
                }
                case "4" -> {
                    System.out.println("");
                    mostrarDatos();
                }
                case "5" -> System.out.println("Saliendo del programa...");
                default -> System.out.println("Ingrese una opción correcta. intentelo nuevamente");
            }
        }while(!"5".equals(opcion));
    }
    
    
}
