/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package instituto;
import java.util.Scanner;
/**
 *
 * @author W608-PCXX
 */
public class Instituto {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        /*
        Mostrar si la persona pertenece a la jornada diurna o vespertina, en el caso de recibir una d o v
        */
        Estudiante estudiante = new Estudiante("Informatica", "1111111", "Nicolás", 22);
        Docente docente = new Docente("Programación","000000", "Juan", 26);
        docente.mostrarDatos();
        System.out.println("Sueldo: " + docente.sueldo());
        Scanner scanner = new Scanner(System.in);
        String opcion;
        do{
          System.out.println("");
            System.out.println("Menu Modificar");
            System.out.println("1.- Modificar docente");
            System.out.println("2.- Modificar estudiante ");
            System.out.println("3.- Salir");
            System.out.println("Ingrese la opción que desea: ");
            opcion = scanner.next();
            if (null == opcion){
                System.out.println("Ingrese una opción correcta. intentelo nuevamente");
            }else switch (opcion) {
                case "1" -> {
                    System.out.println("");
                    docente.actualizarDatos();
                }
                case "2" -> {
                    System.out.println("");
                    estudiante.actualizarDatos();
                }
                case "3" -> System.out.println("Saliendo del programa...");
                default -> System.out.println("Ingrese una opción correcta. intentelo nuevamente");
            }
        }while(!"3".equals(opcion));
    }
    
}
