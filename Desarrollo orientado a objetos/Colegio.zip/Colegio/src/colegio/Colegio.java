/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package colegio;

/**
 *
 * @author W608-PCXX
 */
public class Colegio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        //Sentencia if - else
        //Sentencia para conocer el curso de acuerdo al número ingresado
        int numero = 1;
        switch (numero) {
            case 1 -> System.out.println("Su curso es primero básico");
            case 2 -> System.out.println("Su curso es segundo básico");
            case 3 -> System.out.println("Su curso es tercero básico");
            case 4 -> System.out.println("Su curso es cuarto básico");
            case 5 -> System.out.println("Su curso es quinto básico");
            default -> System.out.println("El curso no existe");
        }
        char sexo = 'm';
        sexo = Character.toUpperCase(sexo);
        if (sexo == 'M'){
            System.out.println("Usted es un hombre.");
        }else if(sexo == 'f') {
            System.out.println("Usted es una mujer.");
        }else{
            System.out.println("Genero no valido.");
        }
    }
}
