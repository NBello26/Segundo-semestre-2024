/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

package colegio;
import java.util.Scanner;
/**
 *
 * @author W608-PCXX
 */
public class Colegio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        //Sentencia if - else
        //Sentencia para conocer el curso de acuerdo al número ingresado
        /*
        int numero = 1;
        switch (numero) {
            case 1 -> System.out.println("Su curso es primero básico");
            case 2 -> System.out.println("Su curso es segundo básico");
            case 3 -> System.out.println("Su curso es tercero básico");
            case 4 -> System.out.println("Su curso es cuarto básico");
            case 5 -> System.out.println("Su curso es quinto básico");
            default -> System.out.println("El curso no existe");
        }
        char sexo = 'm';
        sexo = Character.toUpperCase(sexo);
        if (sexo == 'M'){
            System.out.println("Usted es un hombre.");
        }else if(sexo == 'f') {
            System.out.println("Usted es una mujer.");
        }else{
            System.out.println("Genero no valido.");
        }
        */
        
        /*Como usar while
        int contador = 1;
        while(contador <=5){
            System.out.println(contador);
            System.out.println("Hola mundo");
            contador++; //contador = contador + 1
        }
        */
        
        /*Como usar do while
        int contador = 1;
        do {
            System.out.println(contador);
            System.out.println("Hola mundo");
            contador++; //contador = contador + 1
        } while (contador <=5);
        */
        
        /* Como hacer un menu
        String opcion;
        Scanner teclado = new Scanner(System.in);
        do{
            System.out.println("Menu de opciones");
            System.out.println("");
            System.out.println("1.- Opcion 1");
            System.out.println("2.- Opcion 2");
            System.out.println("3.- Opcion 3");
            System.out.println("4.- Salir");
            System.out.println("Ingrese una opcion: ");
            opcion = teclado.next();
            switch(opcion){
                case "1" -> System.out.println("Ingresaste la opción 1.");
                case "2" -> System.out.println("Ingresaste la opción 2.");
                case "3" -> System.out.println("Ingresaste la opción 3.");
                case "4" -> System.out.println("Ingresaste la opción 4, saldras del programa...");
                default -> System.out.println("Ingresaste una opción invalida.");
            }
            System.out.println("");
        } while (!"4".equals(opcion));
        */
        
        //TAREA: Crear una clase curso con los atributos numero de curso, profe jefe de curso, cantidad de alumnos, con los metodos para mostrar los datos del curso, mostrar nombre del curso
        Curso curso1 = new Curso("1", "Calfun", "20");
        Curso curso2 = new Curso("2", "Rodrigo", "23");
        Curso curso3 = new Curso("3", "Nicolás", "26");
        Curso curso4 = new Curso("4", "Carlitos", "28");
        Curso curso5 = new Curso("5", "Martín", "29");
        
        String opcion;
        Scanner teclado = new Scanner(System.in);
        do{
            System.out.println("Menu de opciones");
            System.out.println("¿Que desea hacer?");
            System.out.println("1.- Mostrar datos");
            System.out.println("2.- Mostrar nombre");
            System.out.println("3.- Salir");
            System.out.println("Ingrese una opcion: ");
            opcion = teclado.next();
            switch(opcion){
                case "1" -> {
                    do {
                        System.out.println("Menu de opciones");
                        System.out.println("¿Que curso desea ver los datos");
                        System.out.println("1.- Curso 1");
                        System.out.println("2.- Curso 2");
                        System.out.println("3.- Curso 3");
                        System.out.println("4.- Curso 4");
                        System.out.println("5.- Curso 5");
                        System.out.println("6.- Salir");
                        System.out.println("Ingrese una opcion: ");
                        opcion = teclado.next();
                        switch (opcion) {
                            case "1" ->
                                curso1.MostarDatos();
                            case "2" ->
                                curso2.MostarDatos();
                            case "3" ->
                                curso3.MostarDatos();
                            case "4" ->
                                curso4.MostarDatos();
                            case "5" ->
                                curso5.MostarDatos();
                            case "6" ->
                                System.out.println("Volviendo al menú principal...");
                            default ->
                                System.out.println("Ingresaste una opción invalida.");
                        }
                        System.out.println("");
                    } while (!"6".equals(opcion));
                }
                case "2" -> {
                    do {
                        System.out.println("Menu de opciones");
                        System.out.println("¿Que curso desea ver el nombre");
                        System.out.println("1.- Curso 1");
                        System.out.println("2.- Curso 2");
                        System.out.println("3.- Curso 3");
                        System.out.println("4.- Curso 4");
                        System.out.println("5.- Curso 5");
                        System.out.println("6.- Salir");
                        System.out.println("Ingrese una opcion: ");
                        opcion = teclado.next();
                        switch (opcion) {
                            case "1" ->
                                curso1.MostrarNombre();
                            case "2" ->
                                curso2.MostrarNombre();
                            case "3" ->
                                curso3.MostrarNombre();
                            case "4" ->
                                curso4.MostrarNombre();
                            case "5" ->
                                curso5.MostrarNombre();
                            case "6" ->
                                System.out.println("Volviendo al menú principal...");
                            default ->
                                System.out.println("Ingresaste una opción invalida.");
                        }
                        System.out.println("");
                    } while (!"6".equals(opcion));
                }
                case "3" -> System.out.println("Saliendo del programa...");
                default -> System.out.println("Ingresaste una opción invalida.");
            }
            System.out.println("");
        } while (!"3".equals(opcion));
    }
}
