/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package colegio;

import java.util.Scanner;

/**
 *
 * @author W608-PCXX
 */
public class Curso {
    private String numerocurso, profesorjefe,cantidadalumnos;

    public Curso(String numerocurso, String profesorjefe, String cantidadalumnos) {
        this.numerocurso = numerocurso;
        this.profesorjefe = profesorjefe;
        this.cantidadalumnos = cantidadalumnos;
    }

    public String getNumerocurso() {
        return numerocurso;
    }

    public String getProfesorjefe() {
        return profesorjefe;
    }

    public String getCantidadalumnos() {
        return cantidadalumnos;
    }

    public void setNumerocurso(String numerocurso) {
        this.numerocurso = numerocurso;
    }

    public void setProfesorjefe(String profesorjefe) {
        this.profesorjefe = profesorjefe;
    }

    public void setCantidadalumnos(String cantidadalumnos) {
        this.cantidadalumnos = cantidadalumnos;
    }
    
    public void MostarDatos(){
        System.out.println("Nùmero del curso: " + getNumerocurso() + " - Profesor Jefe: " + getProfesorjefe() + " - Cantidad de alumnos: " + getCantidadalumnos());
    }

    @Override
    public String toString() {
        return "Curso{" + "numerocurso=" + numerocurso + ", profesorjefe=" + profesorjefe + ", cantidadalumnos=" + cantidadalumnos + '}';
    }
    
    
}
